import React,{useState} from "react";
import OredrNav from "./OrdersNav";
import OrdersPage from "./OrdersPage";


function Oredrs(){
 

    return(
        <>
        <OredrNav />
        <OrdersPage/>
        </>
    )
}

export default Oredrs;