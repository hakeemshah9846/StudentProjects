// import React from 'react';
// import { Link } from 'react-router-dom';
// import './landing.css';

// function LandingNav() {
//   return (
//     <>
//       <title>Shopper.com</title>
//   <meta charSet="UTF-8" />
//   <link type="text/css" rel="stylesheet" href="shopper.css" />
//   <div id="entire_page">
//     <div id="container">

// <div className="navbar">
//         <div className="nav-logo">
//           <Link to="/">
//             <img src='/landing/logo.png' alt="" />
//             <samp className='bebas-neue-regular'>Click</samp>
//             <samp className='lugrasimo-regular'>Shop</samp>
//           </Link>
//         </div>
//         <div className="nav-items">
//           <ul>
//             <li>
//               <Link to="/">Home</Link>
//             </li>
//             <li>
//               <Link to="/shop">Shop</Link>
//             </li>
//             <li>
//               <Link to="/blog">Men</Link>
//             </li>
//             <li>
//               <Link to="/pages">Women</Link>
//             </li>
//             <li>
//               <Link to="/contact">Kids</Link>
//             </li>
//             <li>
//               <a href="#"><span className="material-symbols-outlined">search</span></a>
//             </li>
//             <li>
//               <a href="#"><span className="material-symbols-outlined">shopping_cart</span></a>
//             </li>
//           </ul>
//         </div>
//         <div className="nav-button">
//           <div className="anim-layer" />
//           <a href="#">Login</a>
//         </div>
//         <div id="hamburger-menu">☰</div>
//       </div>

//       <div id="mobile-menu">
//         <div className="mobile-nav-items">
//           <ul>
//             <li>
//               <Link to="/">Home</Link>
//             </li>
//             <li>
//               <Link to="/shop">Shop</Link>
//             </li>
//             <li>
//               <Link to="/blog">Men</Link>
//             </li>
//             <li>
//               <Link to="/pages">Women</Link>
//             </li>
//             <li>
//               <Link to="/contact">Kids</Link>
//             </li>
//           </ul>
//         </div>
//         <div className="mobile-nav-button">
//           <div className="anim-layer" />
//           <a href="#">Login</a>
//         </div>
//         <div id="hamburger-cross">✖</div>
//         </div>


//     </div>
//   </div>
//     </>
//   );
// }

// export default LandingNav;



