import React,{useState} from "react";
import SigninNav from "../sign in/SigninNav";
import SuccessPage from "./SuccessPage";


function Success(){
 

    return(
        <>
        <SigninNav />
        <SuccessPage/>
        </>
    )
}

export default Success;