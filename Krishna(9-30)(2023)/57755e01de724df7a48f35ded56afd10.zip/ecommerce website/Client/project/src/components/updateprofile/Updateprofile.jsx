import React,{useState} from "react";
import UpdateprofileNav from "./UpdateprofileNav";
import Updateprofilepage from "./Updateprofilepage";


function UpdateProfile(){
 

    return(
        <>
        <UpdateprofileNav />
        <Updateprofilepage/>
        </>
    )
}

export default UpdateProfile;