import React,{useState} from "react";

// import UserListPage from "./UserListPage";
// import UserlistNav from "./UserlistNav";
import CreateproductNav from "./CreateproductNav";
import Createproductpage from "./CreatProduct";



function CreateProduct(){
 

    return(
        <>
        <CreateproductNav />
        <Createproductpage/>
        </>
    )
}

export default CreateProduct;