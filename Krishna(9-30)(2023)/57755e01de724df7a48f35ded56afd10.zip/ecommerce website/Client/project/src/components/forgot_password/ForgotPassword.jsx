import ForgotPasswordNav from "./ForgotPasswordNav";
import ForgotPasswordPage from "./ForgotPasswordPage";


export default function ForgotPassword(){
    return(
        <>

        <ForgotPasswordNav/>

        
        <ForgotPasswordPage/>

       
        </>
    )
}