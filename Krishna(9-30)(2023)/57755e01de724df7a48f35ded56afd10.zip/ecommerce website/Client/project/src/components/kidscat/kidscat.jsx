import React,{useState} from "react";
import KidsCatNav from "./KidsCatNav";
import KidsCatpage from "./KidsCatPage";

function KidsCat(){
 

    return(
        <>
        <KidsCatNav />
        <KidsCatpage/>
        </>
    )
}

export default KidsCat;