import React,{useState} from "react";
import ViewCartNav from "./ViewCartNav";
import ViewCartPage from "./ViewCartPage";


function ViewCart(){
 

    return(
        <>
        <ViewCartNav />
        <ViewCartPage/>
        </>
    )
}

export default ViewCart;