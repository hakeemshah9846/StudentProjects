import React,{useState} from "react";
import MensCategoryNav from "./MensCategoryNav";
import MensCategorypage from "./MensCategoryPage";

function MensCategory(){
 

    return(
        <>
        <MensCategoryNav />
        <MensCategorypage/>
        </>
    )
}

export default MensCategory;