import React,{useState} from "react";
import MyOredrNav from "./MyOrdersNav";
import MyOrdersPage from "./MyOrdersPage";


function MyOredrs(){
 

    return(
        <>
        <MyOredrNav />
        <MyOrdersPage/>
        </>
    )
}

export default MyOredrs;