import React,{useState} from "react";
import WomenCategoryNav from "./WomenCategoryNav";
import WomenCategorypage from "./WomenCategoryPage";

function WomenCategory(){
 

    return(
        <>
        <WomenCategoryNav />
        <WomenCategorypage/>
        </>
    )
}

export default WomenCategory;