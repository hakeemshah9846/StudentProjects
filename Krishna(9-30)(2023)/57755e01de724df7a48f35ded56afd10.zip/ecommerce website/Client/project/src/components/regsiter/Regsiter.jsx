import React,{useState} from "react";
import RegsiterNav from "./RegsiterNav";
import Regsiterpage from "./Regsiterpage";


function Regsiter(){
 

    return(
        <>
        <RegsiterNav />
        <Regsiterpage/>
        </>
    )
}

export default Regsiter;