import React,{useState} from "react";
import ProductNav from "./ProductNav";
import ProductPage from "./ProductPage";


function Product(){
 

    return(
        <>
        <ProductNav />
        <ProductPage/>
        </>
    )
}

export default Product;