import React,{useState} from "react";
import KidsCategoryNav from "./KidsCategoryNav";
import KidsCategorypage from "./KidsCategoryPage";

function KidsCategory(){
 

    return(
        <>
        <KidsCategoryNav />
        <KidsCategorypage/>
        </>
    )
}

export default KidsCategory;