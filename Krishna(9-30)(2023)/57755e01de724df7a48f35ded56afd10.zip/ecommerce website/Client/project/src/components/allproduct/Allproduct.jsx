import React,{useState} from "react";
import Allproductpage from "./Allproductpage";
import AllproductNav from "./AllproductNav";


function AllProduct(){
 

    return(
        <>
        <AllproductNav />
        <Allproductpage/>
        </>
    )
}

export default AllProduct;