import React,{useState} from "react";
import MensCatNav from "./MensCatNav";
import MensCatpage from "./MensCatPage";

function MensCat(){
 

    return(
        <>
        <MensCatNav />
        <MensCatpage/>
        </>
    )
}

export default MensCat;