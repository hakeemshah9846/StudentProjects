import React,{useState} from "react";
import ViewFavoriteNav from "./ViewFavoriteNav";
import ViewFavoritepage from "./ViewFavoritePage";


function ViewFavorite(){
 

    return(
        <>
        <ViewFavoriteNav />
        <ViewFavoritepage/>
        </>
    )
}

export default ViewFavorite;