import React,{useState} from "react";
import SigninNav from "./SigninNav";
import Signinpage from "./Signinpage";



function Signin(){
 

    return(
        <>
        <SigninNav />
        <Signinpage/>
        </>
    )
}

export default Signin;