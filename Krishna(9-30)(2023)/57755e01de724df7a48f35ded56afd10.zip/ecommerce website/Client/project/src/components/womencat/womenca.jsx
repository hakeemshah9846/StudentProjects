import React,{useState} from "react";
import WomenCateNav from "./WomenCatNav";
import WomenCatpage from "./WomenCatPage";

function WomenCat(){
 

    return(
        <>
        <WomenCateNav />
        <WomenCatpage/>
        </>
    )
}

export default WomenCat;