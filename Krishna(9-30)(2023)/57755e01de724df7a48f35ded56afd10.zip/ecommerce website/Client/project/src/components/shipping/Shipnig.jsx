import React,{useState} from "react";
import ShippingNav from "./ShippingNav";
import ShippingPage from "./ShippingPage";


function Shipping(){
 

    return(
        <>
        <ShippingNav />
        <ShippingPage/>
        </>
    )
}

export default Shipping;