import React,{useState} from "react";
import UpdateproductNav from "./UpdateproductNav";
import Updateproductpage from "./Updateproductpage";

function UpdateProduct(){
 

    return(
        <>
        <UpdateproductNav />
        <Updateproductpage/>
        </>
    )
}

export default UpdateProduct;