const mongoose = require('mongoose');

const ReviewSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Reference to the 'User' collection
        default: null // Make user field optional
    },
    userEmail: {
        type: String,
        required: false // Make userEmail optional
    },
    rating: {
        type: Number,
        required: true,
        min: 1,
        max: 5
    },
    comment: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

const ProductSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    price: {
        type: Number,
        required: true
    },
    description: {
        type: String,
        required: true,
    },
    category: {
        type: String,
        required: true,
    },
    location: {
        type: String,
        required: true,
    },
    stock: {
        type: Number,
        required: true,
    },
    reviews: [ReviewSchema],  // Embedding ReviewSchema array
    productImage: {
        type: String,
        required: true,
    }
}, {
    timestamps: true  // Automatically add createdAt and updatedAt timestamps
});

module.exports = mongoose.model('Product', ProductSchema);
